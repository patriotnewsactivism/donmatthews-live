# APEX Sales Campaigns + Telnyx Missions

Implemented from the Telnyx documentation reviewed on 2026-09-15.

## What changed

- Added a dedicated **Business → Sales Campaigns** dashboard section.
- Kept **Lead Campaigns** separate from sales outreach.
- Added `/api/sales-campaigns` for a combined email + voice control-plane view.
- Email campaigns now expose operator pause/resume/cancel controls from the dashboard.
- Added a provider-boundary Telnyx Missions client in `packages/core/src/telnyx-missions.ts`.
- Added live Telnyx mission/run monitoring and pause/resume/cancel controls.
- Added an authenticated API endpoint to create a managed Telnyx Mission and start its first run.
- Added Telnyx to the Settings integration catalog.
- Reused the existing `TELNYX_API_KEY`; no secret is committed.

## Architecture

APEX remains the control plane. Resend remains the email delivery provider. Telnyx is treated as a voice execution provider.

The dashboard reads:
- APEX `email_campaigns` + `email_sends` for email.
- Telnyx AI Missions + recent Mission runs for voice.

Telnyx mission IDs and run IDs are provider identifiers, not replacements for APEX campaign identity.

## Endpoints

- `GET /api/sales-campaigns`
- `POST /api/sales-campaigns/email/:id/pause`
- `POST /api/sales-campaigns/email/:id/resume`
- `POST /api/sales-campaigns/email/:id/cancel`
- `POST /api/sales-campaigns/voice`
- `POST /api/sales-campaigns/voice/:missionId/:runId/pause`
- `POST /api/sales-campaigns/voice/:missionId/:runId/resume`
- `POST /api/sales-campaigns/voice/:missionId/:runId/cancel`

## Verification performed here

All modified TypeScript/TSX files were parsed/transpiled with the installed TypeScript compiler and produced no syntax diagnostics.

A full workspace typecheck could not be run in this isolated runtime because this copy of the repository does not include workspace `node_modules`, and Corepack could not download pnpm because external package-registry DNS access is unavailable. Run the repository's normal `pnpm run typecheck:production` after installing dependencies.

## Production activation

1. Set `TELNYX_API_KEY` through APEX Settings or the production secret/environment system.
2. Deploy through the repository's documented Cloud Run release path.
3. Open **Business → Sales Campaigns**.
4. Confirm existing Resend email campaigns appear.
5. Confirm Telnyx connectivity shows configured.
6. Start with a 2–3-call Telnyx Mission and verify pause/resume/cancel and result visibility before increasing volume.
