const TELNYX_API_BASE = 'https://api.telnyx.com/v2';

export interface TelnyxMission {
  mission_id: string;
  name: string;
  description?: string | null;
  model?: string | null;
  instructions?: string | null;
  execution_mode?: 'external' | 'managed' | string;
  created_at?: string;
  updated_at?: string;
}

export interface TelnyxMissionRun {
  run_id: string;
  mission_id: string;
  status: string;
  started_at?: string;
  updated_at?: string;
  result_summary?: string | null;
  result_payload?: unknown;
  input?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

interface TelnyxListResponse<T> {
  data: T[];
  meta?: {
    total_pages?: number;
    total_results?: number;
    page_number?: number;
    page_size?: number;
  };
}

interface TelnyxDataResponse<T> {
  data: T;
}

export class TelnyxApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = 'TelnyxApiError';
  }
}

function getApiKey(): string {
  const apiKey = process.env.TELNYX_API_KEY?.trim();
  if (!apiKey) {
    throw new Error('TELNYX_API_KEY is not configured');
  }
  return apiKey;
}

async function telnyxRequest<T>(
  path: string,
  init: RequestInit = {},
): Promise<T> {
  const response = await fetch(`${TELNYX_API_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${getApiKey()}`,
      'Content-Type': 'application/json',
      ...(init.headers ?? {}),
    },
  });

  const body = await response.text();
  if (!response.ok) {
    throw new TelnyxApiError(
      `Telnyx request failed (${response.status}): ${body.slice(0, 500)}`,
      response.status,
    );
  }

  if (!body) {
    return undefined as T;
  }

  return JSON.parse(body) as T;
}

/**
 * Minimal Telnyx Missions client.
 *
 * APEX owns campaign state. Telnyx remains an execution provider whose mission
 * and run IDs are observed through this boundary, which keeps a future provider
 * migration possible without rewriting the dashboard.
 */
export class TelnyxMissionsClient {
  isConfigured(): boolean {
    return Boolean(process.env.TELNYX_API_KEY?.trim());
  }

  async listMissions(pageSize = 100): Promise<TelnyxMission[]> {
    const response = await telnyxRequest<TelnyxListResponse<TelnyxMission>>(
      `/ai/missions?page[size]=${Math.min(Math.max(pageSize, 1), 1000)}`,
    );
    return response.data ?? [];
  }

  async listRuns(pageSize = 100): Promise<TelnyxMissionRun[]> {
    const response = await telnyxRequest<TelnyxListResponse<TelnyxMissionRun>>(
      `/ai/missions/runs?page[size]=${Math.min(Math.max(pageSize, 1), 1000)}`,
    );
    return response.data ?? [];
  }

  async createMission(input: {
    name: string;
    description?: string;
    model?: string;
    instructions?: string;
    executionMode?: 'external' | 'managed';
    metadata?: Record<string, unknown>;
  }): Promise<TelnyxMission> {
    const response = await telnyxRequest<TelnyxDataResponse<TelnyxMission>>(
      '/ai/missions',
      {
        method: 'POST',
        body: JSON.stringify({
          name: input.name,
          description: input.description,
          model: input.model,
          instructions: input.instructions,
          execution_mode: input.executionMode ?? 'managed',
          metadata: input.metadata,
        }),
      },
    );
    return response.data;
  }

  async startRun(
    missionId: string,
    input?: Record<string, unknown>,
    metadata?: Record<string, unknown>,
  ): Promise<TelnyxMissionRun> {
    const response = await telnyxRequest<TelnyxDataResponse<TelnyxMissionRun>>(
      `/ai/missions/${encodeURIComponent(missionId)}/runs`,
      {
        method: 'POST',
        body: JSON.stringify({ input, metadata }),
      },
    );
    return response.data;
  }

  async pauseRun(missionId: string, runId: string): Promise<TelnyxMissionRun> {
    return this.runAction(missionId, runId, 'pause');
  }

  async resumeRun(missionId: string, runId: string): Promise<TelnyxMissionRun> {
    return this.runAction(missionId, runId, 'resume');
  }

  async cancelRun(missionId: string, runId: string): Promise<TelnyxMissionRun> {
    return this.runAction(missionId, runId, 'cancel');
  }

  private async runAction(
    missionId: string,
    runId: string,
    action: 'pause' | 'resume' | 'cancel',
  ): Promise<TelnyxMissionRun> {
    const response = await telnyxRequest<TelnyxDataResponse<TelnyxMissionRun>>(
      `/ai/missions/${encodeURIComponent(missionId)}/runs/${encodeURIComponent(runId)}/${action}`,
      {
        method: 'POST',
        body: JSON.stringify({}),
      },
    );
    return response.data;
  }
}

let sharedClient: TelnyxMissionsClient | null = null;

export function getTelnyxMissionsClient(): TelnyxMissionsClient {
  sharedClient ??= new TelnyxMissionsClient();
  return sharedClient;
}
