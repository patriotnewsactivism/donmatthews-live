import { z } from 'zod';

// ─── LLM ─────────────────────────────────────────────────────────────────────

// Provider names mirror the runtime chain in llm-client.ts. The actual provider
// used is determined by the OpenRouter routing/fallback chain, so this field is
// primarily for observability/override.
export type LLMProvider = string;

export interface LLMMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  toolCallId?: string;
  name?: string;
  toolCalls?: LLMToolCall[];
}

export interface LLMTool {
  name: string;
  description: string;
  parameters: Record<string, unknown>; // JSON Schema
}

export interface LLMToolCall {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

export interface LLMRouterAttempt {
  provider?: string;
  model?: string;
  status?: number;
}

/**
 * Privacy-minimized subset of OpenRouter router metadata. APEX intentionally
 * keeps only routing identity/status fields; summaries, pipeline payloads and
 * other free-form router data are not persisted into model-learning telemetry.
 */
export interface LLMRouterMetadata {
  requested?: string;
  strategy?: string;
  attempt?: number;
  selectedProvider?: string;
  attempts?: LLMRouterAttempt[];
}

export interface LLMResponse {
  content: string;
  toolCalls: LLMToolCall[];
  usage: { promptTokens: number; completionTokens: number };
  /** Existing diagnostic label: logical provider + actual served model. */
  model: string;
  /** Actual model ID reported by OpenRouter, without the logical provider prefix. */
  servedModel?: string;
  /** Ordered model IDs sent to the gateway for this generation. */
  requestedModels?: string[];
  /** Privacy-minimized OpenRouter routing audit metadata, when returned. */
  routerMetadata?: LLMRouterMetadata;
  /** End-to-end provider request latency observed by APEX. */
  latencyMs?: number;
  /** OpenRouter-reported generation cost when supplied in usage.cost. */
  costUsd?: number | null;
  cachedTokens?: number;
  reasoningTokens?: number;
  // Set when the response was served by a provider that does not reliably
  // emit structured tool calls. The agent loop can use this to prompt again.
  degraded?: boolean;
}

/** Per-call attribution supplied by the agent loop. It contains identifiers and
 * a coarse pre-run complexity hint only — never prompt/completion content. */
export interface LLMExecutionContext {
  taskId?: string;
  agentId?: string;
  role?: string;
  complexityHint?: number;
}

export interface LLMClientConfig {
  provider: LLMProvider;
  model: string;
  apiKey?: string;
  baseUrl?: string;
  temperature?: number;
  maxTokens?: number;
  // Agent role (e.g. 'LEAD_DEV', 'QA') — used to pick role-appropriate models.
  role?: string;
}

// ─── Tools ────────────────────────────────────────────────────────────────────

export interface ToolDefinition<TInput = unknown, TOutput = unknown> {
  name: string;
  description: string;
  parameters?: Record<string, unknown>;
  schema: z.ZodSchema<TInput>;
  requiresApproval: boolean;
  execute: (input: TInput, context: ToolContext) => Promise<TOutput>;
}

export interface ToolContext {
  agentId: string;
  taskId?: string;
  goalId?: string;
  workspaceRoot: string;
  requestApproval: (toolName: string, args: unknown, reason: string) => Promise<boolean>;
  delegateToRole?: (targetRole: string, input: { title: string; description: string; parentTaskId?: string; context?: Record<string, unknown> }) => Promise<string>;
  delegateToAgent?: (targetAgentId: string, input: { title: string; description: string; parentTaskId?: string; goalId?: string; context?: Record<string, unknown> }) => Promise<string>;
}

export interface ToolResult {
  success: boolean;
  data?: unknown;
  error?: string;
}

// ─── Agent ────────────────────────────────────────────────────────────────────

export type AgentRole =
  | 'CEO'
  | 'CTO'
  | 'COO'
  | 'LEAD_DEV'
  | 'FRONTEND'
  | 'BACKEND'
  | 'DEVOPS'
  | 'QA'
  | 'RESEARCH'
  | 'DOCS'
  | 'OPS'
  | 'LEAD_RESEARCH'
  | 'SALES'
  | 'MARKETING'
  | 'CUSTOMER_SUCCESS'
  | 'QA_DIRECTOR';

export type AgentStatus = 'idle' | 'thinking' | 'acting' | 'blocked' | 'done' | 'error';

export type TaskStatus =
  | 'pending'
  | 'in_progress'
  | 'blocked'
  | 'awaiting_approval'
  | 'done'
  | 'failed'
  | 'cancelled';

export interface AgentConfig {
  id: string;
  name: string;
  role: AgentRole;
  tier: number;
  parentId?: string;
  systemPrompt: string;
  llm: LLMClientConfig;
  tools: string[]; // tool names this agent is allowed to use
  maxIterations?: number; // safety limit for autonomous loops
  approvalRequired?: boolean; // gate all actions through human approval
  // Max tasks this agent instance will run concurrently from its own queue.
  // Default 1 preserves existing strictly-sequential behavior. Bump this for
  // roles that receive dispatchSwarm fan-outs (e.g. QA_DIRECTOR, LEAD_RESEARCH)
  // so N independent swarm instances actually execute in parallel instead of
  // queuing up behind one another.
  concurrency?: number;
}

// ─── Tasks ────────────────────────────────────────────────────────────────────

export interface TaskInput {
  title: string;
  description: string;
  goalId?: string;
  parentTaskId?: string;
  priority?: number;
  context?: Record<string, unknown>;
}

export interface TaskResult {
  success: boolean;
  output?: string;
  artifacts?: string[]; // file paths created
  error?: string;
  subTasks?: string[]; // IDs of spawned sub-tasks
  // Set when this execution slice ended by checkpointing and yielding back to
  // the queue (soft deadline or approval yield) rather than by completing or
  // failing the task. `success` stays true because a yield is neither — see
  // task-checkpoint.ts.
  yielded?: boolean;
}

// ─── Events (for WebSocket broadcast) ────────────────────────────────────────

export type ApexEvent =
  | { type: 'agent:status'; agentId: string; status: AgentStatus; message?: string }
  | { type: 'task:created'; taskId: string; title: string; assignedAgentId?: string }
  | { type: 'task:updated'; taskId: string; status: TaskStatus; result?: string }
  | { type: 'goal:created'; goalId: string; title: string }
  | { type: 'goal:updated'; goalId: string; status: string }
  | { type: 'log'; agentId?: string; taskId?: string; level: string; message: string; timestamp: number }
  | { type: 'approval:requested'; approvalId: string; agentId: string; toolName: string; reason: string }
  // 'acknowledged' applies only to kind='escalation': an escalation authorizes
  // no tool call, so approving it would misrepresent what happened. It is a
  // message the reader has seen and cleared.
  | { type: 'approval:resolved'; approvalId: string; status: 'approved' | 'rejected' | 'acknowledged' }
  | { type: 'memory:updated'; agentId: string; key: string }
  | { type: 'message:sent'; messageId: string; fromAgentId: string; toAgentId: string; subject: string }
  | { type: 'health:updated'; overall: string; checks: Record<string, unknown>; timestamp: string }
  | { type: 'health:alert'; alertId: string; severity: string; message: string; component: string }
  // ── Lead campaigns ────────────────────────────────────────────────────────
  // A lead hunt runs for hours across dozens of territory segments. Polling
  // alone makes it look static between refreshes; these are what let the
  // dashboard show a campaign actually moving.
  | { type: 'campaign:started'; campaignId: string; name: string; targetLeads: number; segments: number }
  | { type: 'campaign:progress'; campaignId: string; leadsSaved: number; targetLeads: number; segmentsDone: number; segmentsTotal: number }
  | { type: 'campaign:segment'; campaignId: string; segmentId: string; industry: string; city: string; status: string; saved: number; found: number }
  | { type: 'campaign:completed'; campaignId: string; status: string; leadsSaved: number; targetLeads: number };
