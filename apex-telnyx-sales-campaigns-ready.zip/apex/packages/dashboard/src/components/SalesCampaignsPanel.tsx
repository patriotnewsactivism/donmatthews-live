import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, type EmailSalesCampaign, type TelnyxMissionSummary } from '../lib/api.js';
import { Mail, PhoneCall, Pause, Play, Square, RefreshCw, AlertTriangle } from 'lucide-react';

function statusColor(status: string): string {
  if (['running', 'in_progress', 'active'].includes(status)) return 'var(--color-apex-green)';
  if (['paused', 'pending', 'queued'].includes(status)) return 'var(--color-apex-brass)';
  if (['failed', 'bounced', 'complained'].includes(status)) return 'var(--color-apex-red)';
  if (['completed', 'succeeded', 'delivered'].includes(status)) return 'var(--color-apex-signal)';
  return 'var(--color-apex-muted)';
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div
      style={{
        padding: '12px 14px',
        border: '1px solid var(--color-apex-line)',
        borderRadius: 6,
        background: 'rgba(255,255,255,0.02)',
      }}
    >
      <div className="apex-eyebrow" style={{ marginBottom: 5 }}>{label}</div>
      <div className="apex-display" style={{ fontSize: 20, color: 'var(--color-apex-text)' }}>{value}</div>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '4px 8px',
        borderRadius: 999,
        border: `1px solid ${statusColor(status)}55`,
        color: statusColor(status),
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        textTransform: 'uppercase',
        letterSpacing: '0.05em',
      }}
    >
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: statusColor(status) }} />
      {status}
    </span>
  );
}

function CampaignActions({
  status,
  onAction,
  busy,
}: {
  status: string;
  onAction: (action: 'pause' | 'resume' | 'cancel') => void;
  busy: boolean;
}) {
  const canPause = ['running', 'in_progress', 'active'].includes(status);
  const canResume = status === 'paused';
  const canCancel = !['completed', 'cancelled', 'canceled', 'succeeded', 'failed'].includes(status);

  return (
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      {canPause && (
        <button className="btn-secondary" disabled={busy} onClick={() => onAction('pause')}>
          <Pause size={13} /> Pause
        </button>
      )}
      {canResume && (
        <button className="btn-secondary" disabled={busy} onClick={() => onAction('resume')}>
          <Play size={13} /> Resume
        </button>
      )}
      {canCancel && (
        <button className="btn-secondary" disabled={busy} onClick={() => onAction('cancel')}>
          <Square size={13} /> Stop
        </button>
      )}
    </div>
  );
}

function EmailCampaignCard({
  campaign,
  onAction,
  busy,
}: {
  campaign: EmailSalesCampaign;
  onAction: (id: string, action: 'pause' | 'resume' | 'cancel') => void;
  busy: boolean;
}) {
  const delivered = campaign.counts.delivered ?? 0;
  const opened = campaign.counts.opened ?? 0;
  const clicked = campaign.counts.clicked ?? 0;
  const bounced = campaign.counts.bounced ?? 0;
  const queued = campaign.counts.queued ?? 0;

  return (
    <div className="glass-card" style={{ padding: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16, alignItems: 'flex-start' }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <Mail size={16} color="var(--color-apex-brass)" />
            <strong style={{ color: 'var(--color-apex-text)' }}>{campaign.name}</strong>
          </div>
          <div style={{ color: 'var(--color-apex-muted)', fontSize: 12 }}>
            {campaign.subjectTemplate}
          </div>
        </div>
        <StatusPill status={campaign.status} />
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit,minmax(90px,1fr))',
          gap: 8,
          marginTop: 16,
        }}
      >
        <Stat label="Targets" value={campaign.totalTargets} />
        <Stat label="Sent" value={campaign.sentCount} />
        <Stat label="Queued" value={queued} />
        <Stat label="Delivered" value={delivered} />
        <Stat label="Opened" value={opened} />
        <Stat label="Clicked" value={clicked} />
        <Stat label="Bounced" value={bounced} />
        <Stat label="Failed" value={campaign.failedCount} />
      </div>

      <div style={{ marginTop: 16 }}>
        <CampaignActions
          status={campaign.status}
          busy={busy}
          onAction={(action) => onAction(campaign.id, action)}
        />
      </div>

      {campaign.recentSends.length > 0 && (
        <div style={{ marginTop: 16, borderTop: '1px solid var(--color-apex-line)', paddingTop: 12 }}>
          <div className="apex-eyebrow" style={{ marginBottom: 8 }}>Recent recipients</div>
          <div style={{ display: 'grid', gap: 6 }}>
            {campaign.recentSends.slice(0, 5).map((send) => (
              <div
                key={send.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  gap: 10,
                  fontFamily: 'var(--font-mono)',
                  fontSize: 11,
                  color: 'var(--color-apex-muted)',
                }}
              >
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {send.toName ? `${send.toName} · ` : ''}{send.toEmail}
                </span>
                <span style={{ color: statusColor(send.status), flexShrink: 0 }}>{send.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function VoiceMissionCard({
  mission,
  onAction,
  busy,
}: {
  mission: TelnyxMissionSummary;
  onAction: (missionId: string, runId: string, action: 'pause' | 'resume' | 'cancel') => void;
  busy: boolean;
}) {
  const run = mission.latestRun;
  return (
    <div className="glass-card" style={{ padding: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16, alignItems: 'flex-start' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <PhoneCall size={16} color="var(--color-apex-purple)" />
            <strong style={{ color: 'var(--color-apex-text)' }}>{mission.name}</strong>
          </div>
          <div style={{ color: 'var(--color-apex-muted)', fontSize: 12 }}>
            {mission.description || 'Telnyx AI Mission'}
          </div>
        </div>
        <StatusPill status={run?.status ?? 'idle'} />
      </div>

      {run ? (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(140px,1fr))', gap: 8, marginTop: 16 }}>
            <Stat label="Run" value={run.runId.slice(0, 8)} />
            <Stat label="Started" value={run.startedAt ? new Date(run.startedAt).toLocaleString() : '—'} />
            <Stat label="Updated" value={run.updatedAt ? new Date(run.updatedAt).toLocaleString() : '—'} />
          </div>
          {run.resultSummary && (
            <div style={{ marginTop: 12, color: 'var(--color-apex-muted)', fontSize: 12, lineHeight: 1.5 }}>
              {run.resultSummary}
            </div>
          )}
          <div style={{ marginTop: 16 }}>
            <CampaignActions
              status={run.status}
              busy={busy}
              onAction={(action) => onAction(mission.missionId, run.runId, action)}
            />
          </div>
        </>
      ) : (
        <div style={{ marginTop: 16, color: 'var(--color-apex-muted)', fontSize: 12 }}>
          No run has been started for this mission.
        </div>
      )}
    </div>
  );
}

export function SalesCampaignsPanel() {
  const queryClient = useQueryClient();
  const overview = useQuery({
    queryKey: ['sales-campaigns'],
    queryFn: () => api.salesCampaigns.overview(),
    refetchInterval: 10_000,
  });

  const emailControl = useMutation({
    mutationFn: ({ id, action }: { id: string; action: 'pause' | 'resume' | 'cancel' }) =>
      api.salesCampaigns.controlEmail(id, action),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['sales-campaigns'] }),
  });

  const voiceControl = useMutation({
    mutationFn: ({ missionId, runId, action }: { missionId: string; runId: string; action: 'pause' | 'resume' | 'cancel' }) =>
      api.salesCampaigns.controlVoice(missionId, runId, action),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['sales-campaigns'] }),
  });

  if (overview.isLoading) {
    return <div style={{ color: 'var(--color-apex-muted)' }}>Loading sales campaigns…</div>;
  }

  if (overview.error || !overview.data) {
    return (
      <div className="glass-card" style={{ padding: 20, color: 'var(--color-apex-red)' }}>
        <AlertTriangle size={18} style={{ marginRight: 8, verticalAlign: 'middle' }} />
        {overview.error instanceof Error ? overview.error.message : 'Unable to load sales campaigns.'}
      </div>
    );
  }

  const { email, voice } = overview.data;
  const activeEmail = email.filter((campaign) => campaign.status === 'running').length;
  const activeVoice = voice.missions.filter((mission) =>
    ['running', 'in_progress', 'active', 'pending'].includes(mission.latestRun?.status ?? ''),
  ).length;

  return (
    <div style={{ display: 'grid', gap: 18 }}>
      <div
        className="glass-card"
        style={{
          padding: 18,
          display: 'flex',
          justifyContent: 'space-between',
          gap: 16,
          alignItems: 'center',
          flexWrap: 'wrap',
        }}
      >
        <div>
          <div className="apex-eyebrow">Outbound control plane</div>
          <div className="apex-display" style={{ color: 'var(--color-apex-text)', fontSize: 22, marginTop: 4 }}>
            Email + Voice Campaigns
          </div>
          <div style={{ color: 'var(--color-apex-muted)', fontSize: 12, marginTop: 5 }}>
            Email is sourced from APEX/Resend. Voice is sourced live from Telnyx AI Missions.
          </div>
        </div>
        <button
          className="btn-secondary"
          onClick={() => overview.refetch()}
          disabled={overview.isFetching}
        >
          <RefreshCw size={13} /> Refresh
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', gap: 10 }}>
        <Stat label="Email campaigns" value={email.length} />
        <Stat label="Active email" value={activeEmail} />
        <Stat label="Voice missions" value={voice.missions.length} />
        <Stat label="Active voice" value={activeVoice} />
      </div>

      <section>
        <div className="apex-eyebrow" style={{ marginBottom: 10 }}>Email / Resend</div>
        <div style={{ display: 'grid', gap: 12 }}>
          {email.length === 0 ? (
            <div className="glass-card" style={{ padding: 18, color: 'var(--color-apex-muted)' }}>
              No outbound email campaigns exist yet.
            </div>
          ) : email.map((campaign) => (
            <EmailCampaignCard
              key={campaign.id}
              campaign={campaign}
              busy={emailControl.isPending}
              onAction={(id, action) => emailControl.mutate({ id, action })}
            />
          ))}
        </div>
      </section>

      <section>
        <div className="apex-eyebrow" style={{ marginBottom: 10 }}>Voice / Telnyx AI Missions</div>
        {!voice.configured ? (
          <div className="glass-card" style={{ padding: 18, color: 'var(--color-apex-muted)' }}>
            TELNYX_API_KEY is not configured. Add it in Settings → Telnyx to enable live mission monitoring.
          </div>
        ) : voice.error ? (
          <div className="glass-card" style={{ padding: 18, color: 'var(--color-apex-red)' }}>
            Telnyx is configured, but the Missions API could not be read: {voice.error}
          </div>
        ) : voice.missions.length === 0 ? (
          <div className="glass-card" style={{ padding: 18, color: 'var(--color-apex-muted)' }}>
            Telnyx is connected. No AI Missions exist yet.
          </div>
        ) : (
          <div style={{ display: 'grid', gap: 12 }}>
            {voice.missions.map((mission) => (
              <VoiceMissionCard
                key={mission.missionId}
                mission={mission}
                busy={voiceControl.isPending}
                onAction={(missionId, runId, action) =>
                  voiceControl.mutate({ missionId, runId, action })
                }
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
