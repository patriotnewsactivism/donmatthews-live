import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { api } from '../lib/api.js';
import type { LearningInsightRow, StrategyRecommendationRow } from '../lib/api.js';
import {
  Brain,
  TrendingUp,
  Lightbulb,
  CheckCircle,
  XCircle,
  Clock,
  Sparkles,
  Zap,
  Check,
  X,
  RefreshCw,
  BarChart3,
  Rocket,
} from 'lucide-react';

export function LearningPanel() {
  const queryClient = useQueryClient();
  const [pendingPage, setPendingPage] = useState(1);
  const [pendingSearch, setPendingSearch] = useState('');
  const [historyPage, setHistoryPage] = useState(1);
  const [historyStatus, setHistoryStatus] = useState('approved,applied,rejected,superseded');
  const [historySearch, setHistorySearch] = useState('');
  const [cleanupPreview, setCleanupPreview] = useState<Awaited<ReturnType<typeof api.learning.cleanupRecommendations>> | null>(null);

  const { data: outcomes = [], isLoading: isLoadingOutcomes } = useQuery({
    queryKey: ['learning-outcomes'],
    queryFn: () => api.learning.outcomes(),
    refetchInterval: 15_000,
  });

  const { data: insights = [] } = useQuery({
    queryKey: ['learning-insights'],
    queryFn: () => api.learning.insights(),
    refetchInterval: 15_000,
  });

  const { data: recommendationPage } = useQuery({
    queryKey: ['learning-recommendations', 'pending', pendingPage, pendingSearch],
    queryFn: () => api.learning.recommendations({ status: 'pending', page: pendingPage, pageSize: 25, search: pendingSearch }),
    refetchInterval: 15_000,
  });
  const recommendations = recommendationPage?.items ?? [];

  const { data: historyPageData } = useQuery({
    queryKey: ['learning-recommendations-history', historyPage, historyStatus, historySearch],
    queryFn: () => api.learning.recommendations({ status: historyStatus, page: historyPage, pageSize: 25, search: historySearch }),
    refetchInterval: 30_000,
  });

  const analyzeMutation = useMutation({
    mutationFn: () => api.learning.analyze(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['learning-insights'] });
      queryClient.invalidateQueries({ queryKey: ['learning-recommendations'] });
    },
  });

  const respondMutation = useMutation({
    mutationFn: ({ id, action }: { id: string; action: 'approve' | 'reject' }) =>
      api.learning.respondRecommendation(id, action),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['learning-recommendations'] });
    },
  });

  const applyMutation = useMutation({
    mutationFn: (id: string) => api.learning.applyRecommendation(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['learning-recommendations'] });
      queryClient.invalidateQueries({ queryKey: ['agents'] });
    },
  });

  const cleanupMutation = useMutation({
    mutationFn: (execute: boolean) => api.learning.cleanupRecommendations(execute),
    onSuccess: (summary) => {
      setCleanupPreview(summary);
      queryClient.invalidateQueries({ queryKey: ['learning-recommendations'] });
      queryClient.invalidateQueries({ queryKey: ['learning-recommendations-history'] });
    },
  });

  const totalTasks = outcomes.length;
  const successCount = outcomes.filter((o) => o.success).length;
  const successRate = totalTasks > 0 ? (successCount / totalTasks) * 100 : 100;
  const avgDurationMs =
    totalTasks > 0
      ? outcomes.reduce((sum, o) => sum + o.durationMs, 0) / totalTasks
      : 0;

  return (
    <div style={{ padding: '24px 32px', maxWidth: 1200 }}>
      {/* Header & Trigger */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 24,
        }}
      >
        <div>
          <h2
            style={{
              margin: 0,
              fontSize: 22,
              fontWeight: 700,
              color: '#f1f5f9',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
            }}
          >
            <Brain size={24} color="#5a9eae" /> Learning & Adaptation System
          </h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: '#94a3b8' }}>
            Continuous performance tracking, automated pattern recognition, and approval-gated strategy optimization
          </p>
        </div>
        <button
          onClick={() => analyzeMutation.mutate()}
          disabled={analyzeMutation.isPending}
          style={{
            padding: '10px 18px',
            borderRadius: 8,
            background: 'linear-gradient(135deg, rgba(90,158,174,0.2), rgba(59,130,246,0.2))',
            border: '1px solid rgba(90,158,174,0.4)',
            color: '#5a9eae',
            fontSize: 13,
            fontWeight: 600,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          <Sparkles size={16} className={analyzeMutation.isPending ? 'animate-spin' : ''} />
          {analyzeMutation.isPending ? 'Analyzing...' : 'Run Pattern Analysis'}
        </button>
      </div>

      {/* KPI Cards */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 240px), 1fr))',
          gap: 16,
          marginBottom: 28,
        }}
      >
        <div className="glass-card" style={{ padding: '20px 24px', borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#94a3b8', display: 'flex', alignItems: 'center', gap: 6 }}>
            <TrendingUp size={14} color="#22c55e" /> Success Rate
          </div>
          <div style={{ fontSize: 28, fontWeight: 700, color: '#f8fafc', marginTop: 8 }}>
            {successRate.toFixed(1)}%
          </div>
          <div style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>
            {successCount} / {totalTasks} tasks completed successfully
          </div>
        </div>

        <div className="glass-card" style={{ padding: '20px 24px', borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#94a3b8', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Clock size={14} color="#3b82f6" /> Avg Execution Time
          </div>
          <div style={{ fontSize: 28, fontWeight: 700, color: '#f8fafc', marginTop: 8 }}>
            {(avgDurationMs / 1000).toFixed(1)}s
          </div>
          <div style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>
            Across {totalTasks} tracked task outcomes
          </div>
        </div>

        <div className="glass-card" style={{ padding: '20px 24px', borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#94a3b8', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Lightbulb size={14} color="#eab308" /> Active Insights
          </div>
          <div style={{ fontSize: 28, fontWeight: 700, color: '#f8fafc', marginTop: 8 }}>
            {insights.length}
          </div>
          <div style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>
            Automated patterns & improvements
          </div>
        </div>

        <div className="glass-card" style={{ padding: '20px 24px', borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#94a3b8', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Zap size={14} color="#a855f7" /> Strategy Queue
          </div>
          <div style={{ fontSize: 28, fontWeight: 700, color: '#f8fafc', marginTop: 8 }}>
            {recommendationPage?.pagination.total ?? 0}
          </div>
          <div style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>
            Pending human approval
          </div>
        </div>
      </div>

      {/* Grid for Insights & Recommendations */}
      <div className="apex-grid-collapse" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Learning Insights Feed */}
        <div>
          <h3 style={{ fontSize: 15, fontWeight: 600, color: '#cbd5e1', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Lightbulb size={16} color="#eab308" /> Learning Insights Feed
          </h3>
          {insights.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: '#64748b', background: 'rgba(255,255,255,0.02)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.06)' }}>
              No insights generated yet. Execute more tasks or click "Run Pattern Analysis" above.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {insights.map((insight) => (
                <motion.div
                  key={insight.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  style={{
                    background: 'rgba(15,23,42,0.6)',
                    border: '1px solid rgba(255,255,255,0.08)',
                    borderRadius: 12,
                    padding: '16px 20px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontSize: 14, fontWeight: 600, color: '#f1f5f9' }}>{insight.title}</span>
                    <span style={{
                      padding: '2px 8px',
                      borderRadius: 10,
                      fontSize: 10,
                      fontWeight: 700,
                      background: insight.insightType === 'warning' ? 'rgba(239,68,68,0.2)' : 'rgba(34,197,94,0.2)',
                      color: insight.insightType === 'warning' ? '#ef4444' : '#22c55e',
                    }}>
                      {(insight.confidence * 100).toFixed(0)}% confidence
                    </span>
                  </div>
                  <p style={{ margin: 0, fontSize: 12, color: '#94a3b8', lineHeight: 1.4 }}>{insight.description}</p>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Strategy Recommendations Queue */}
        <div>
          <div className="apex-toolbar" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: '#cbd5e1', margin: 0, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Zap size={16} color="#a855f7" /> Strategy Recommendations (Approval Gated)
            </h3>
            <input
              className="apex-input"
              style={{ maxWidth: 200 }}
              value={pendingSearch}
              onChange={(event) => { setPendingSearch(event.target.value); setPendingPage(1); }}
              placeholder="Filter pending"
            />
          </div>
          {recommendations.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: '#64748b', background: 'rgba(255,255,255,0.02)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.06)' }}>
              No pending strategy recommendations.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {recommendations.map((rec) => (
                <motion.div
                  key={rec.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  style={{
                    background: 'rgba(15,23,42,0.6)',
                    border: '1px solid rgba(168,85,247,0.3)',
                    borderRadius: 12,
                    padding: '16px 20px',
                  }}
                >
                  <div className="apex-toolbar" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontSize: 14, fontWeight: 600, color: '#f1f5f9' }}>{rec.title}</span>
                    <span style={{ fontSize: 11, color: '#a855f7', fontWeight: 600 }}>{rec.status.toUpperCase()}</span>
                  </div>
                  <p style={{ margin: '4px 0 8px', fontSize: 12, color: '#94a3b8', lineHeight: 1.4 }}>{rec.text}</p>
                  <div style={{ fontSize: 11, color: '#22c55e', fontStyle: 'italic', marginBottom: 12 }}>
                    Impact: {rec.expectedImpact}
                  </div>
                  {rec.status === 'pending' && (
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      <button
                        onClick={() => respondMutation.mutate({ id: rec.id, action: 'approve' })}
                        style={{
                          padding: '6px 12px',
                          borderRadius: 6,
                          background: 'rgba(34,197,94,0.2)',
                          border: '1px solid rgba(34,197,94,0.4)',
                          color: '#22c55e',
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                        }}
                      >
                        <Check size={14} /> Approve
                      </button>
                      <button
                        onClick={() => respondMutation.mutate({ id: rec.id, action: 'reject' })}
                        style={{
                          padding: '6px 12px',
                          borderRadius: 6,
                          background: 'rgba(239,68,68,0.2)',
                          border: '1px solid rgba(239,68,68,0.4)',
                          color: '#ef4444',
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                        }}
                      >
                        <X size={14} /> Reject
                      </button>
                      <button
                        onClick={() => applyMutation.mutate(rec.id)}
                        style={{
                          padding: '6px 12px',
                          borderRadius: 6,
                          background: 'rgba(168,85,247,0.2)',
                          border: '1px solid rgba(168,85,247,0.4)',
                          color: '#a855f7',
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                        }}
                      >
                        <Rocket size={14} /> Apply Now
                      </button>
                    </div>
                  )}
                  {rec.duplicateCount > 0 && <div style={{ fontSize: 11, color: '#64748b' }}>{rec.duplicateCount} duplicate audit record(s)</div>}
                </motion.div>
              ))}
            </div>
          )}
          {(recommendationPage?.pagination.totalPages ?? 1) > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10, marginTop: 12 }}>
              <button className="apex-button" disabled={pendingPage <= 1} onClick={() => setPendingPage((page) => page - 1)}>Previous</button>
              <span style={{ color: '#94a3b8', padding: 8 }}>Page {pendingPage} of {recommendationPage?.pagination.totalPages || 1}</span>
              <button className="apex-button" disabled={pendingPage >= (recommendationPage?.pagination.totalPages || 1)} onClick={() => setPendingPage((page) => page + 1)}>Next</button>
            </div>
          )}
        </div>
      </div>

      <section style={{ marginTop: 28 }}>
        <div className="apex-toolbar" style={{ display: 'flex', justifyContent: 'space-between', gap: 12, marginBottom: 12 }}>
          <h3 style={{ margin: 0, fontSize: 15, color: '#cbd5e1' }}>Strategy History</h3>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <select className="apex-input" value={historyStatus} onChange={(event) => { setHistoryStatus(event.target.value); setHistoryPage(1); }}>
              <option value="approved,applied,rejected,superseded">All history</option>
              <option value="approved">Approved</option><option value="applied">Applied</option>
              <option value="rejected">Rejected</option><option value="superseded">Superseded</option>
            </select>
            <input className="apex-input" value={historySearch} onChange={(event) => { setHistorySearch(event.target.value); setHistoryPage(1); }} placeholder="Filter history" />
            <button className="apex-button" onClick={() => cleanupMutation.mutate(false)} disabled={cleanupMutation.isPending}>Clean duplicate queue</button>
          </div>
        </div>
        {cleanupPreview && (
          <div className="glass-card" style={{ padding: 14, marginBottom: 12, color: '#cbd5e1', fontSize: 12 }}>
            Examined {cleanupPreview.totalRowsExamined}; {cleanupPreview.semanticGroupsFound} groups; pending {cleanupPreview.pendingCountBefore} → {cleanupPreview.pendingCountAfter}; {cleanupPreview.unsafeConcurrencyItemsRejected} unsafe concurrency item(s).
            {cleanupPreview.dryRun && (
              <button className="apex-button" style={{ marginLeft: 12 }} onClick={() => { if (window.confirm('Supersede the duplicate queue records shown in this dry run? Audit rows will be preserved.')) cleanupMutation.mutate(true); }}>Confirm cleanup</button>
            )}
          </div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {(historyPageData?.items ?? []).map((rec) => (
            <div key={rec.id} className="glass-card" style={{ padding: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}><strong>{rec.title}</strong><span>{rec.status.toUpperCase()}</span></div>
              <div style={{ fontSize: 12, color: '#94a3b8' }}>{rec.expectedImpact}</div>
              <div style={{ fontSize: 11, color: '#64748b' }}>{rec.duplicateCount} duplicate/superseded record(s) · observed {rec.occurrences} time(s)</div>
              {rec.status === 'approved' && <button className="apex-button" onClick={() => applyMutation.mutate(rec.id)}><Rocket size={14} /> Apply</button>}
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 10, marginTop: 12 }}>
          <button className="apex-button" disabled={historyPage <= 1} onClick={() => setHistoryPage((page) => page - 1)}>Previous</button>
          <span style={{ color: '#94a3b8', padding: 8 }}>Page {historyPage} of {historyPageData?.pagination.totalPages || 1}</span>
          <button className="apex-button" disabled={historyPage >= (historyPageData?.pagination.totalPages || 1)} onClick={() => setHistoryPage((page) => page + 1)}>Next</button>
        </div>
      </section>
    </div>
  );
}
