import { Router } from 'express';
import { z } from 'zod';
import { desc, eq } from 'drizzle-orm';
import { db, emailCampaigns, emailSends } from '@workspace/db';
import { getTelnyxMissionsClient } from '@workspace/core';

const createTelnyxMissionSchema = z.object({
  name: z.string().min(3).max(120),
  description: z.string().max(1000).optional(),
  instructions: z.string().min(10).max(20_000),
  model: z.string().max(200).optional(),
  input: z.record(z.string(), z.unknown()).optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

const EMAIL_LIVE_STATUSES = new Set(['running', 'paused']);

function countStatuses(rows: Array<typeof emailSends.$inferSelect>) {
  const counts: Record<string, number> = {};
  for (const row of rows) {
    counts[row.status] = (counts[row.status] ?? 0) + 1;
  }
  return counts;
}

export function createSalesCampaignsRouter(): Router {
  const router = Router();
  const telnyx = getTelnyxMissionsClient();

  router.get('/', async (_req, res) => {
    try {
      const campaigns = await db
        .select()
        .from(emailCampaigns)
        .orderBy(desc(emailCampaigns.createdAt))
        .limit(100);

      const sends = await db.select().from(emailSends);
      const sendsByCampaign = new Map<string, Array<typeof emailSends.$inferSelect>>();
      for (const send of sends) {
        if (!send.campaignId) continue;
        const list = sendsByCampaign.get(send.campaignId) ?? [];
        list.push(send);
        sendsByCampaign.set(send.campaignId, list);
      }

      let voice: {
        configured: boolean;
        missions: Array<{
          missionId: string;
          name: string;
          description?: string | null;
          updatedAt?: string;
          latestRun?: {
            runId: string;
            status: string;
            startedAt?: string;
            updatedAt?: string;
            resultSummary?: string | null;
          };
        }>;
        error?: string;
      } = {
        configured: telnyx.isConfigured(),
        missions: [],
      };

      if (voice.configured) {
        try {
          const [missions, runs] = await Promise.all([
            telnyx.listMissions(100),
            telnyx.listRuns(100),
          ]);
          const latestRunByMission = new Map<string, (typeof runs)[number]>();
          for (const run of runs) {
            const previous = latestRunByMission.get(run.mission_id);
            if (
              !previous ||
              Date.parse(run.updated_at ?? run.started_at ?? '1970-01-01') >
                Date.parse(previous.updated_at ?? previous.started_at ?? '1970-01-01')
            ) {
              latestRunByMission.set(run.mission_id, run);
            }
          }

          voice.missions = missions.map((mission) => {
            const latest = latestRunByMission.get(mission.mission_id);
            return {
              missionId: mission.mission_id,
              name: mission.name,
              description: mission.description,
              updatedAt: mission.updated_at,
              latestRun: latest
                ? {
                    runId: latest.run_id,
                    status: latest.status,
                    startedAt: latest.started_at,
                    updatedAt: latest.updated_at,
                    resultSummary: latest.result_summary,
                  }
                : undefined,
            };
          });
        } catch (err) {
          voice.error = err instanceof Error ? err.message : String(err);
        }
      }

      res.json({
        email: campaigns.map((campaign) => {
          const rows = sendsByCampaign.get(campaign.id) ?? [];
          return {
            ...campaign,
            counts: countStatuses(rows),
            recentSends: rows
              .slice()
              .sort(
                (a, b) =>
                  b.createdAt.getTime() - a.createdAt.getTime(),
              )
              .slice(0, 10),
          };
        }),
        voice,
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : String(err),
      });
    }
  });

  router.post('/email/:id/:action', async (req, res) => {
    const action = req.params.action;
    if (!['pause', 'resume', 'cancel'].includes(action)) {
      res.status(404).json({ error: 'Unknown campaign action' });
      return;
    }

    const [campaign] = await db
      .select()
      .from(emailCampaigns)
      .where(eq(emailCampaigns.id, req.params.id))
      .limit(1);

    if (!campaign) {
      res.status(404).json({ error: 'Email campaign not found' });
      return;
    }

    if (!EMAIL_LIVE_STATUSES.has(campaign.status)) {
      res.status(409).json({
        error: `Campaign is ${campaign.status} and cannot be ${action}d.`,
      });
      return;
    }

    const nextStatus =
      action === 'pause'
        ? 'paused'
        : action === 'resume'
          ? 'running'
          : 'cancelled';

    await db
      .update(emailCampaigns)
      .set({
        status: nextStatus,
        lastProgressAt: new Date(),
        ...(nextStatus === 'cancelled'
          ? {
              completedAt: new Date(),
              result: 'Cancelled by operator from Sales Campaigns.',
            }
          : {}),
      })
      .where(eq(emailCampaigns.id, campaign.id));

    res.json({ campaignId: campaign.id, status: nextStatus });
  });

  router.post('/voice', async (req, res) => {
    if (!telnyx.isConfigured()) {
      res.status(503).json({ error: 'TELNYX_API_KEY is not configured' });
      return;
    }

    const parsed = createTelnyxMissionSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.flatten() });
      return;
    }

    try {
      const mission = await telnyx.createMission({
        name: parsed.data.name,
        description: parsed.data.description,
        instructions: parsed.data.instructions,
        model: parsed.data.model,
        executionMode: 'managed',
        metadata: parsed.data.metadata,
      });
      const run = await telnyx.startRun(
        mission.mission_id,
        parsed.data.input,
        parsed.data.metadata,
      );
      res.status(201).json({ mission, run });
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : String(err),
      });
    }
  });

  router.post('/voice/:missionId/:runId/:action', async (req, res) => {
    const { missionId, runId, action } = req.params;
    if (!['pause', 'resume', 'cancel'].includes(action)) {
      res.status(404).json({ error: 'Unknown run action' });
      return;
    }

    try {
      const run =
        action === 'pause'
          ? await telnyx.pauseRun(missionId, runId)
          : action === 'resume'
            ? await telnyx.resumeRun(missionId, runId)
            : await telnyx.cancelRun(missionId, runId);

      res.json({ run });
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : String(err),
      });
    }
  });

  return router;
}
